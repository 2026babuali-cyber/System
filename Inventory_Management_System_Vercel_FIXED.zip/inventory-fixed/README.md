# Inventory Management System — Vercel Ready

## What was repaired
- Removed the broken `frontend/` routing/build arrangement.
- Put `index.html`, `style.css`, and `app.js` at the project root so Vercel serves CSS/JS correctly.
- Moved the FastAPI server to `api/index.py`, which is the standard Vercel Python function layout.
- Simplified Python dependencies to avoid unnecessary build failures.
- Added responsive mobile/tablet layout.
- Added working demo login through `/api/login`.
- Added health endpoint: `/api/health`.

## Demo login
Username: `admin`
Password: `password`

## Deploy with GitHub + Vercel
1. Extract this ZIP.
2. Upload all files inside this folder to a GitHub repository (do not upload the outer ZIP folder itself).
3. In Vercel choose **Add New → Project → Import Git Repository**.
4. Select the repository and deploy. Leave the framework preset as **Other** and keep the root directory at the repository root.
5. After deployment open your Vercel domain. You should see the login page.

## Important
This version is a functional demo UI/API. The master and transaction screens use sample data and alert messages. For permanent Purchase, Sales, Stock, Party and report storage, connect a PostgreSQL database and implement CRUD endpoints.
