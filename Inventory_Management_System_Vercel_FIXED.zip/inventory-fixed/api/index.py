from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="Inventory Management API", version="1.0.1")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

class Login(BaseModel):
    username: str
    password: str

@app.get("/api/health")
def health():
    return {"status": "ok", "service": "inventory-management-api"}

@app.post("/api/login")
def login(data: Login):
    if data.username == "admin" and data.password == "password":
        return {"success": True, "token": "demo-token", "user": {"username": "admin", "role": "admin"}}
    raise HTTPException(status_code=401, detail="Invalid username or password")

@app.get("/api/financial-years")
def financial_years():
    return [{"name": x} for x in ["2025-26", "2026-27", "2027-28"]]

@app.get("/api/items")
def items():
    return []

@app.get("/api/parties")
def parties():
    return []

@app.get("/api/stock")
def stock(financial_year: str = "2026-27"):
    return {"financial_year": financial_year, "items": []}
